from django.urls import path
from . import views

app_name = 'shop'

urlpatterns = [
    path('', views.index, name='index'),
    path('products/', views.ProductListView.as_view(), name='product_list'),
    path('category/<slug:category_slug>/',
         views.ProductListView.as_view(),
         name='product_list_by_category'),
    path('product/<int:pk>/<slug:slug>/',
         views.ProductDetailView.as_view(),
         name='product_detail'),
    path('product/<int:product_id>/review/',
         views.ReviewCreateView.as_view(),
         name='add_review'),
    path('wishlist/', views.WishlistView.as_view(), name='wishlist'),
    path('wishlist/add/<int:product_id>/',
         views.add_to_wishlist,
         name='add_to_wishlist'),
    path('wishlist/remove/<int:product_id>/',
         views.remove_from_wishlist,
         name='remove_from_wishlist'),
    path('history/', views.ViewHistoryView.as_view(), name='view_history'),
    path('api/search-autocomplete/',
         views.search_autocomplete,
         name='search_autocomplete'),
]

# Инициализация проекта computer_shop_project

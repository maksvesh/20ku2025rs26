# Shop application initialization

# Orders application initialization

# Cart application initialization
